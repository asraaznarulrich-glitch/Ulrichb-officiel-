import Header from "@/components/Header";
import Hero from "@/components/Hero";
import IntroduceMe from "@/components/IntroduceMe";
import CritiqueCard from "@/components/CritiqueCard";
import ChroniqueCard from "@/components/ChroniqueCard";
import SelectionList from "@/components/SelectionList";
import Footer from "@/components/Footer";
import { critiques, chroniques, selections } from "@/lib/content";

export default function Home() {
  return (
    <>
      <Header />
      <main id="contenu">
        <Hero />
        <IntroduceMe />

        <section id="critiques" className="mx-auto max-w-content px-6 py-20 md:py-28">
          <div className="max-w-prose">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-wine">
              Critiques
            </p>
            <h2 className="mt-3 text-balance font-display text-3xl italic md:text-4xl">
              Des films qui ne savent pas s'ils doivent vous faire rire ou pleurer
            </h2>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {critiques.map((critique) => (
              <CritiqueCard key={critique.slug} critique={critique} />
            ))}
          </div>
        </section>

        <section id="chroniques" className="bg-parchment-dim">
          <div className="mx-auto max-w-content px-6 py-20 md:py-28">
            <div className="max-w-prose">
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-wine">
                Chroniques
              </p>
              <h2 className="mt-3 text-balance font-display text-3xl italic md:text-4xl">
                Des leçons de vie empruntées au grand écran
              </h2>
            </div>
            <div className="mt-10 max-w-prose">
              {chroniques.map((chronique) => (
                <ChroniqueCard key={chronique.slug} chronique={chronique} />
              ))}
            </div>
          </div>
        </section>

        <section id="selections" className="mx-auto max-w-content px-6 py-20 md:py-28">
          <div className="max-w-prose">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-wine">
              Sélections
            </p>
            <h2 className="mt-3 text-balance font-display text-3xl italic md:text-4xl">
              Des listes pour chaque état d'âme
            </h2>
          </div>
          <div className="mt-10">
            {selections.map((selection) => (
              <SelectionList key={selection.title} selection={selection} />
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
