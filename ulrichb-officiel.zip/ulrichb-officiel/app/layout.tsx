import type { Metadata } from "next";
import { Fraunces, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  style: ["normal", "italic"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-fraunces",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-inter",
  display: "swap",
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-plex-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Ulrich B. Officiel — Comédies dramatiques & conseils qui rient un peu",
  description:
    "Critiques de comédies dramatiques et chroniques de vie sur le ton de l'auto-dérision, par Ulrich B.",
  metadataBase: new URL("https://ulrichb-officiel.vercel.app"),
  openGraph: {
    title: "Ulrich B. Officiel",
    description:
      "Critiques de comédies dramatiques et chroniques de vie qui rient un peu.",
    type: "website",
    locale: "fr_FR",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="fr"
      className={`${fraunces.variable} ${inter.variable} ${plexMono.variable}`}
    >
      <body>
        <a
          href="#contenu"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:rounded focus:bg-marquee focus:px-4 focus:py-2 focus:text-ink focus:font-body focus:font-semibold"
        >
          Aller au contenu
        </a>
        {children}
      </body>
    </html>
  );
}
