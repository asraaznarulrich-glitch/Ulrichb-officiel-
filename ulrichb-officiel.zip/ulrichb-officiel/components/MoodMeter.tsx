interface MoodMeterProps {
  /** 0 = pure comédie, 100 = pur drame. */
  score: number;
  className?: string;
  /** Text tone to match the surrounding surface. Defaults to dark text for light cards. */
  tone?: "dark" | "light";
}

// A small analog dial, styled after a theatre applause-meter, that plots a
// work's real position between comedy and drama. The needle angle encodes
// the actual moodScore rather than decorating the card — the same data
// point could be read as a number, but the dial is how this site chose to
// say it.
export default function MoodMeter({ score, className = "", tone = "dark" }: MoodMeterProps) {
  const clamped = Math.max(0, Math.min(100, score));
  const textStrong = tone === "dark" ? "text-ink" : "text-parchment";
  const textMuted = tone === "dark" ? "text-ink/50" : "text-parchment/60";
  // Needle sweeps from -80deg (RIRE) to +80deg (LARMES) across a semicircle.
  const angle = -80 + (clamped / 100) * 160;
  const label = clamped < 40 ? "Plutôt rire" : clamped > 60 ? "Plutôt larmes" : "Mi-figue, mi-raisin";

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <svg
        width="72"
        height="44"
        viewBox="0 0 72 44"
        role="img"
        aria-label={`Curseur comédie-drame : ${label}, ${clamped} sur 100 vers le drame`}
        className="shrink-0"
      >
        <path
          d="M 6 40 A 30 30 0 0 1 66 40"
          fill="none"
          stroke="#1C1310"
          strokeOpacity="0.15"
          strokeWidth="5"
          strokeLinecap="round"
        />
        <path
          d="M 6 40 A 30 30 0 0 1 66 40"
          fill="none"
          stroke="#8FA050"
          strokeOpacity="0.55"
          strokeWidth="5"
          strokeLinecap="round"
          strokeDasharray="47 141"
        />
        <path
          d="M 6 40 A 30 30 0 0 1 66 40"
          fill="none"
          stroke="#7A2E3A"
          strokeOpacity="0.55"
          strokeWidth="5"
          strokeLinecap="round"
          strokeDasharray="47 141"
          strokeDashoffset="-94"
        />
        <g
          className="origin-[36px_40px] transition-transform duration-700 ease-out"
          style={{ transform: `rotate(${angle}deg)` }}
        >
          <line x1="36" y1="40" x2="36" y2="14" stroke="#D9A441" strokeWidth="2.5" strokeLinecap="round" />
        </g>
        <circle cx="36" cy="40" r="3" fill="#1C1310" />
      </svg>
      <div className="font-mono text-[11px] uppercase tracking-wider leading-tight">
        <div className={`flex justify-between gap-4 ${textMuted}`}>
          <span>Rire</span>
          <span>Larmes</span>
        </div>
        <div className={`mt-0.5 ${textStrong}`}>{label}</div>
      </div>
    </div>
  );
}
