const facts = [
  { label: "Basé à", value: "Paris" },
  { label: "Films vus", value: "800+" },
  { label: "Genre de prédilection", value: "Comédie dramatique" },
  { label: "Devise", value: "Rire d'abord, comprendre ensuite" },
];

export default function IntroduceMe() {
  return (
    <section id="introduce-me" className="mx-auto max-w-content px-6 py-20 md:py-28">
      <div className="grid gap-10 md:grid-cols-[minmax(0,280px)_1fr] md:items-start md:gap-14">
        {/* Portrait placeholder — swap the div below for a real <Image> once
            a photo is available; the frame and caption already expect it. */}
        <div>
          <div
            className="flex aspect-[4/5] w-full items-center justify-center rounded-2xl border border-ink/10 bg-fig text-parchment/40"
            role="img"
            aria-label="Portrait d'Ulrich B. à venir"
          >
            <span className="font-display text-6xl italic text-marquee/70">UB</span>
          </div>
          <p className="mt-3 font-mono text-[11px] uppercase tracking-wider text-ink/40">
            Photo à venir
          </p>
        </div>

        <div>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-wine">
            Introduce me
          </p>
          <h2 className="mt-3 text-balance font-display text-3xl italic md:text-4xl">
            Je m'appelle Ulrich B.
          </h2>
          <div className="mt-5 max-w-prose space-y-4 font-body text-[15px] leading-relaxed text-ink/80">
            <p>
              J'écris sur les films qui refusent de choisir entre le rire et
              les larmes — parce que je pense qu'ils disent quelque chose de
              plus juste sur la vie que les comédies pures ou les drames
              lourds. Ce site est né d'une habitude : sortir d'une séance
              bouleversé et hilare en même temps, et vouloir en parler.
            </p>
            <p>
              Chaque semaine, une critique et une chronique. Pas de notation
              sur 5 étoiles, pas de spoilers non annoncés — juste un point de
              vue assumé, et un cadran qui te dit à quoi t'attendre avant de
              lire.
            </p>
          </div>

          <dl className="mt-8 grid grid-cols-2 gap-x-6 gap-y-5 border-t border-ink/10 pt-6 sm:grid-cols-4">
            {facts.map((fact) => (
              <div key={fact.label}>
                <dt className="font-mono text-[10px] uppercase tracking-wider text-ink/40">
                  {fact.label}
                </dt>
                <dd className="mt-1 font-display text-lg italic leading-snug">
                  {fact.value}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}
