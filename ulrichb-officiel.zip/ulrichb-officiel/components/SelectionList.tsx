import type { Selection } from "@/lib/content";

export default function SelectionList({ selection }: { selection: Selection }) {
  return (
    <div className="rounded-2xl bg-fig p-8 text-parchment md:p-10">
      <h3 className="font-display text-2xl italic md:text-3xl">{selection.title}</h3>
      <p className="mt-2 max-w-prose font-body text-parchment/70">{selection.intro}</p>
      <ol className="mt-6 space-y-3">
        {selection.items.map((item, index) => (
          <li key={item} className="flex gap-4 border-t border-parchment/10 pt-3 first:border-0 first:pt-0">
            <span className="font-mono text-sm text-marquee">
              {String(index + 1).padStart(2, "0")}
            </span>
            <span className="font-body text-[15px] leading-relaxed text-parchment/90">{item}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}
