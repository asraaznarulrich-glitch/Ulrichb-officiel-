import type { Chronique } from "@/lib/content";

export default function ChroniqueCard({ chronique }: { chronique: Chronique }) {
  return (
    <article className="border-b border-ink/10 py-6 first:pt-0 last:border-0">
      <div className="flex items-center gap-3 font-mono text-[11px] uppercase tracking-wider text-wine">
        <span>{chronique.tag}</span>
        <span aria-hidden="true" className="text-ink/20">
          —
        </span>
        <time>{chronique.date}</time>
      </div>
      <h3 className="mt-2 font-display text-xl leading-snug">{chronique.title}</h3>
      <p className="mt-2 max-w-prose font-body text-[15px] leading-relaxed text-ink/75">
        {chronique.excerpt}
      </p>
      <a
        href={`#${chronique.slug}`}
        className="mt-3 inline-flex items-center gap-1 font-mono text-xs uppercase tracking-wider text-ink underline decoration-marquee decoration-2 underline-offset-4 hover:text-wine"
      >
        Lire la chronique
      </a>
    </article>
  );
}
