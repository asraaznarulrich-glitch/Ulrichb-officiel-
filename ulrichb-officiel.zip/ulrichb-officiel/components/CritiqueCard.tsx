import type { Critique } from "@/lib/content";
import MoodMeter from "./MoodMeter";

export default function CritiqueCard({ critique }: { critique: Critique }) {
  return (
    <article className="flex h-full flex-col rounded-2xl border border-ink/10 bg-white/40 p-6 transition-shadow hover:shadow-lg hover:shadow-ink/5">
      <p className="font-mono text-[11px] uppercase tracking-wider text-wine">
        {critique.tagline} · {critique.year}
      </p>
      <h3 className="mt-2 font-display text-2xl italic leading-snug">
        {critique.title}
      </h3>
      <p className="mt-1 font-mono text-xs text-ink/50">{critique.director}</p>
      <p className="mt-4 flex-1 font-body text-[15px] leading-relaxed text-ink/80">
        {critique.excerpt}
      </p>
      <div className="mt-5 flex flex-wrap gap-2">
        {critique.themes.map((theme) => (
          <span
            key={theme}
            className="rounded-full bg-olive/15 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-[#5C6A32]"
          >
            {theme}
          </span>
        ))}
      </div>
      <div className="mt-6 border-t border-ink/10 pt-4">
        <MoodMeter score={critique.moodScore} />
      </div>
    </article>
  );
}
