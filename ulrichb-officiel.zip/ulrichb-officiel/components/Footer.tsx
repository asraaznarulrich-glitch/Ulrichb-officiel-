export default function Footer() {
  return (
    <footer id="apropos" className="border-t border-ink/10 bg-parchment-dim">
      <div className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-10 md:grid-cols-[1.2fr_1fr]">
          <div>
            <h2 className="font-display text-2xl italic">À propos d'Ulrich B.</h2>
            <p className="mt-3 max-w-prose font-body text-[15px] leading-relaxed text-ink/75">
              Ce site rassemble des critiques de comédies dramatiques et des
              chroniques de vie écrites sur le même ton : sérieux sur le fond,
              jamais sur la forme. L'idée n'est pas de choisir entre rire et
              émotion, mais de montrer qu'ils viennent rarement l'un sans
              l'autre.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl italic">Newsletter</h2>
            <p className="mt-3 font-body text-[15px] text-ink/75">
              Une chronique par semaine, jamais plus. Pas de spam, pas de
              fausse promesse de "10 astuces".
            </p>
            <form className="mt-4 flex flex-col gap-3 sm:flex-row" aria-label="Inscription à la newsletter">
              <label htmlFor="email" className="sr-only">
                Adresse e-mail
              </label>
              <input
                id="email"
                type="email"
                required
                placeholder="ton@email.fr"
                className="w-full rounded-full border border-ink/20 bg-white px-4 py-2.5 font-body text-sm text-ink placeholder:text-ink/40 focus:border-marquee"
              />
              <button
                type="submit"
                className="shrink-0 rounded-full bg-ink px-5 py-2.5 font-mono text-xs uppercase tracking-wider text-parchment transition-colors hover:bg-wine"
              >
                S'inscrire
              </button>
            </form>
          </div>
        </div>
        <div className="mt-12 flex flex-col gap-2 border-t border-ink/10 pt-6 font-mono text-xs text-ink/50 sm:flex-row sm:items-center sm:justify-between">
          <span>© {new Date().getFullYear()} Ulrich B. Officiel — Tous droits réservés.</span>
          <span>Fait avec un peu de rire, un peu de larmes.</span>
        </div>
      </div>
    </footer>
  );
}
