const links = [
  { href: "#introduce-me", label: "Introduce me" },
  { href: "#critiques", label: "Critiques" },
  { href: "#chroniques", label: "Chroniques" },
  { href: "#selections", label: "Sélections" },
  { href: "#apropos", label: "À propos" },
];

export default function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-parchment/10 bg-fig/95 backdrop-blur">
      <div className="mx-auto flex max-w-content items-center justify-between px-6 py-4">
        <a
          href="#hero"
          className="font-display italic text-xl text-parchment tracking-tight"
        >
          Ulrich B.
        </a>
        <nav aria-label="Navigation principale" className="hidden gap-8 md:flex">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="font-mono text-xs uppercase tracking-wider text-parchment/70 transition-colors hover:text-marquee"
            >
              {link.label}
            </a>
          ))}
        </nav>
        <a
          href="#chroniques"
          className="hidden rounded-full border border-marquee/60 px-4 py-1.5 font-mono text-xs uppercase tracking-wider text-marquee transition-colors hover:bg-marquee hover:text-ink md:inline-block"
        >
          Newsletter
        </a>
        {/* Mobile: nav collapses to a simple inline list rather than a hidden
            drawer, so it stays keyboard- and screen-reader-friendly without
            extra script. */}
        <nav aria-label="Navigation principale" className="flex gap-4 md:hidden">
          {links.slice(0, 2).map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="font-mono text-xs uppercase tracking-wider text-parchment/70 hover:text-marquee"
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
