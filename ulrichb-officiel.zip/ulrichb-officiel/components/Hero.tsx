import MoodMeter from "./MoodMeter";

export default function Hero() {
  return (
    <section id="hero" className="bg-fig text-parchment">
      <div className="mx-auto max-w-content px-6 py-20 md:py-28">
        <p className="animate-rise-in font-mono text-xs uppercase tracking-[0.2em] text-marquee">
          Critiques &amp; chroniques — comédie dramatique
        </p>
        <h1 className="mt-6 max-w-3xl text-balance font-display text-5xl italic leading-[1.05] md:text-7xl">
          <span className="animate-rise-in block" style={{ animationDelay: "0.08s" }}>
            Le rire pleure
          </span>
          <span className="animate-rise-in block text-marquee" style={{ animationDelay: "0.18s" }}>
            un peu, toujours.
          </span>
        </h1>
        <p
          className="animate-rise-in mt-6 max-w-prose font-body text-lg text-parchment/80"
          style={{ animationDelay: "0.28s" }}
        >
          Ulrich B. décortique les comédies dramatiques qui refusent de choisir
          leur camp, et en tire des chroniques de vie qu'on peut lire sans
          sortir les mouchoirs — enfin, presque.
        </p>
        <div
          className="animate-rise-in mt-9 flex flex-wrap items-center gap-4"
          style={{ animationDelay: "0.36s" }}
        >
          <a
            href="#critiques"
            className="rounded-full bg-marquee px-6 py-3 font-mono text-xs uppercase tracking-wider text-ink transition-transform hover:-translate-y-0.5"
          >
            Lire les critiques
          </a>
          <a
            href="#chroniques"
            className="rounded-full border border-parchment/30 px-6 py-3 font-mono text-xs uppercase tracking-wider text-parchment transition-colors hover:border-marquee hover:text-marquee"
          >
            Voir les chroniques
          </a>
        </div>
        <div
          className="animate-rise-in mt-14 max-w-xs rounded-xl border border-parchment/10 bg-fig-light/60 p-4"
          style={{ animationDelay: "0.44s" }}
        >
          <p className="mb-2 font-mono text-[10px] uppercase tracking-wider text-parchment/50">
            Le curseur du jour
          </p>
          <MoodMeter score={42} tone="light" />
        </div>
      </div>
    </section>
  );
}
