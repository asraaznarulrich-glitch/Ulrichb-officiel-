// Central content store. Swap this for a CMS (Notion, Sanity...) later
// without touching the components — they only read these shapes.

export interface Critique {
  slug: string;
  title: string;
  year: number;
  director: string;
  tagline: string;
  excerpt: string;
  /** 0 = pure comédie ("RIRE"), 100 = pure drame ("LARMES"). */
  moodScore: number;
  themes: string[];
}

export interface Chronique {
  slug: string;
  title: string;
  date: string;
  tag: string;
  excerpt: string;
}

export interface Selection {
  title: string;
  intro: string;
  items: string[];
}

export const critiques: Critique[] = [
  {
    slug: "little-miss-sunshine",
    title: "Little Miss Sunshine",
    year: 2006,
    director: "Jonathan Dayton & Valerie Faris",
    tagline: "Road-trip familial",
    excerpt:
      "Un minibus jaune, une famille en pleine débâcle et un concours de beauté improbable : le film prouve qu'on peut filmer l'échec sans jamais être pathétique. Chaque personnage porte sa propre catastrophe, et c'est justement leur addition qui finit par ressembler à de l'amour.",
    moodScore: 35,
    themes: ["Famille", "Échec", "Résilience"],
  },
  {
    slug: "toni-erdmann",
    title: "Toni Erdmann",
    year: 2016,
    director: "Maren Ade",
    tagline: "Comédie de la maladresse",
    excerpt:
      "Un père encombrant s'invite dans la vie hyper-cadrée de sa fille, déguisé en consultant loufoque. Le film étire les scènes jusqu'au malaise, puis les fait basculer dans un rire nerveux — la meilleure définition du tragicomique qu'on ait vue depuis longtemps.",
    moodScore: 55,
    themes: ["Filiation", "Travail", "Absurde"],
  },
  {
    slug: "la-famille-belier",
    title: "La Famille Bélier",
    year: 2014,
    director: "Éric Lartigau",
    tagline: "Chronique rurale",
    excerpt:
      "Seule entendante d'une famille sourde, une adolescente doit choisir entre son foyer et un rêve de chant. Le film assume ses gros sabots comiques sans jamais désamorcer la vraie question qu'il pose : à quel moment partir devient un acte d'amour plutôt qu'un abandon.",
    moodScore: 25,
    themes: ["Émancipation", "Famille", "Musique"],
  },
];

export const chroniques: Chronique[] = [
  {
    slug: "lecon-echec-sunshine",
    title: "Ce que Little Miss Sunshine m'a appris sur l'échec",
    date: "12 mai 2026",
    tag: "Chronique",
    excerpt:
      "Personne dans ce film ne gagne vraiment. C'est précisément pour ça qu'il m'a réconcilié avec mes propres ratages — et voici comment j'ai fini par en rire, de bonne foi cette fois.",
  },
  {
    slug: "survivre-repas-famille",
    title: "Survivre à un repas de famille : mode d'emploi comique",
    date: "28 avril 2026",
    tag: "Conseils",
    excerpt:
      "Trois techniques d'improvisation empruntées au cinéma pour désamorcer la table de Noël, du sujet politique de tonton à la question gênante sur ta vie amoureuse.",
  },
  {
    slug: "syndrome-imposteur-standup",
    title: "Le syndrome de l'imposteur, version stand-up",
    date: "9 avril 2026",
    tag: "Chronique",
    excerpt:
      "Et si la meilleure réponse à cette petite voix qui doute n'était pas de la faire taire, mais de lui écrire un sketch ? Un exercice à faire chez soi, sans scène ni public.",
  },
];

export const selections: Selection[] = [
  {
    title: "5 films à voir après une rupture",
    intro:
      "Pas de quoi se lamenter seul devant un mouchoir : ces films rient de la peine autant qu'ils la traversent.",
    items: [
      "Little Miss Sunshine — pour se rappeler qu'une famille cassée avance quand même",
      "Toni Erdmann — pour rire de ce qu'on ne contrôle plus",
      "La Famille Bélier — pour la scène de karaoké qui répare tout, un peu",
      "Silver Linings Playbook — pour la danse maladroite qui vaut toutes les thérapies",
      "Frances Ha — pour l'art de rebondir sans avoir de plan",
    ],
  },
];
