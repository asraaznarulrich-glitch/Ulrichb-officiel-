# Ulrich B. Officiel

Site de critiques de comédies dramatiques et de chroniques de vie, construit
avec **Next.js 14** (App Router), **TypeScript** et **Tailwind CSS**, prêt à
être déployé sur **Vercel**.

## Structure du projet

```
app/
  layout.tsx        → coquille HTML, polices, métadonnées SEO
  page.tsx           → page d'accueil (assemble toutes les sections)
  globals.css         → styles de base, focus visible, réduction de mouvement
components/
  Header.tsx           → navigation
  Hero.tsx              → section d'ouverture
  MoodMeter.tsx        → cadran signature "Rire ↔ Larmes"
  CritiqueCard.tsx     → carte de critique de film
  ChroniqueCard.tsx    → carte de chronique
  SelectionList.tsx    → liste thématique ("5 films à voir après...")
  Footer.tsx            → newsletter + bas de page
lib/
  content.ts             → tout le contenu texte (films, chroniques, sélections)
```

Pour ajouter ou modifier un article, il suffit d'éditer `lib/content.ts` —
aucun composant n'a besoin d'être touché.

## Lancer le site en local

Prérequis : [Node.js](https://nodejs.org) 18 ou plus récent.

```bash
npm install
npm run dev
```

Le site est alors disponible sur `http://localhost:3000`.

## Déployer sur Vercel

**Option recommandée — via GitHub :**

1. Crée un dépôt sur [GitHub](https://github.com) et pousse ce projet :
   ```bash
   git init
   git add .
   git commit -m "Premier commit — Ulrich B. Officiel"
   git branch -M main
   git remote add origin https://github.com/<ton-compte>/ulrichb-officiel.git
   git push -u origin main
   ```
2. Va sur [vercel.com](https://vercel.com), clique sur **Add New → Project**.
3. Sélectionne le dépôt GitHub que tu viens de créer.
4. Vercel détecte automatiquement Next.js — laisse les réglages par défaut et
   clique sur **Deploy**.
5. Le site est en ligne sur une adresse `https://ulrichb-officiel.vercel.app`
   (ou similaire). Tu pourras brancher ton propre nom de domaine plus tard
   depuis **Project Settings → Domains**.

**Option rapide — via la CLI Vercel (sans GitHub) :**

```bash
npm install -g vercel
vercel
```

Suis les instructions à l'écran ; Vercel construit et déploie le projet
directement depuis ton dossier local.

## Prochaines étapes suggérées

- Créer une page dédiée par critique (`app/critiques/[slug]/page.tsx`) pour
  que chaque article ait sa propre URL.
- Brancher Google Analytics / Search Console une fois le domaine en place.
- Remplacer le formulaire newsletter statique par un service comme Mailchimp,
  Resend ou Beehiiv.
- Ajouter des liens d'affiliation (streaming, billetterie) dans
  `lib/content.ts`.
