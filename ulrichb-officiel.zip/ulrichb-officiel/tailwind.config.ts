import type { Config } from "tailwindcss";

// Design tokens for Ulrich B. Officiel — a tragicomedy film & life-advice site.
// Palette is built around the "fig / grape" duality of comedy-drama:
// deep aubergine and wine for the dramatic register, olive for the comic
// relief, warm parchment for reading surfaces, and a marquee gold for the
// single accent that ties everything back to the theatre.
const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        fig: {
          DEFAULT: "#2A1B28",
          light: "#3C2A38",
        },
        wine: {
          DEFAULT: "#7A2E3A",
          light: "#9C4152",
        },
        olive: {
          DEFAULT: "#8FA050",
          light: "#A9B96E",
        },
        parchment: {
          DEFAULT: "#F2EBDA",
          dim: "#E8DEC7",
        },
        ink: "#1C1310",
        marquee: "#D9A441",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "ui-serif", "Georgia", "serif"],
        body: ["var(--font-inter)", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["var(--font-plex-mono)", "ui-monospace", "monospace"],
      },
      maxWidth: {
        content: "72rem",
        prose: "42rem",
      },
      keyframes: {
        "rise-in": {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "sweep": {
          "0%": { transform: "rotate(var(--from))" },
          "100%": { transform: "rotate(var(--to))" },
        },
      },
      animation: {
        "rise-in": "rise-in 0.7s cubic-bezier(0.16, 1, 0.3, 1) both",
        "sweep": "sweep 1.1s cubic-bezier(0.16, 1, 0.3, 1) both",
      },
    },
  },
  plugins: [],
};

export default config;
